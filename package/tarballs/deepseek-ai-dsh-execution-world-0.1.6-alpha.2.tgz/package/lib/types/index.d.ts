import { Context, Service } from '@deepseek-ai/cordis';
import schema from '@deepseek-ai/schemastery';
import type { ExecutionWorkspaceId } from './types.ts';
export type { ExecutionWorkspaceId } from './types.ts';
/** Deployment identity selection; remote deployments must explicitly choose their own UUID. */
export interface Config {
    /** Local identity is persisted once; deployment identity is supplied by the operator. */
    mode: 'persisted-local' | 'deployment';
    /** Stable UUID shared by aliases of one remote world, never by different worlds. */
    deploymentId?: string;
    /** Absolute Host coordination path shared by every process using this identity store. */
    allocationLockPath: string;
    /** Maximum wait for another identity transaction, in milliseconds. */
    lockWaitMs?: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        executionWorldIdentity: ExecutionWorldIdentity;
    }
}
/** Owns durable identity allocation, not execution handles or remote transport. */
export declare class ExecutionWorldIdentity extends Service {
    static inject: string[];
    static Config: schema<Config>;
    private readonly config;
    private readonly lifetime;
    private worldId;
    private tail;
    private readonly operations;
    /**
     * @param ctx - owner with durable storage and the execution filesystem.
     * @param config - explicit local or deployment identity mode.
     */
    constructor(ctx: Context, config: Config);
    /** Open durable records before publishing this service. */
    protected [Service.init](): Promise<void>;
    private withDomain;
    /**
     * Resolve an existing directory through the current filesystem and durably allocate its identity.
     * Concurrent aliases share one allocation. Disposal rejects outstanding resolutions; an allocation
     * already committed before cancellation remains available on the next call or restart.
     * @param root - directory in the mounted filesystem's execution world.
     * @param signal - caller cancellation, combined with this provider's lifetime.
     * @returns the same opaque ID after recreation with the same storage and world configuration.
     */
    resolve(root: string, signal?: AbortSignal): Promise<ExecutionWorkspaceId>;
    private resolveRoot;
}
export default ExecutionWorldIdentity;
//# sourceMappingURL=index.d.ts.map