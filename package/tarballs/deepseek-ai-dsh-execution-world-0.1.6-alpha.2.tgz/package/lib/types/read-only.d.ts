/** Lifecycle-bound root reads and file-effect-confined processes over explicitly paired providers. */
import { Context } from '@deepseek-ai/cordis';
import type { ReadOnlyExecutionWorld } from './read-only-types.ts';
/**
 * Capture explicitly injected identity, filesystem, subprocess and sandbox provider generations.
 * Matching live affinity and identity's exact filesystem dependency are required before root I/O.
 * Filesystem paths are checked before reads; concurrent namespace replacement is not isolated.
 * This internal binding is not a security boundary for exposing repository contents.
 * Subprocess confinement restricts file effects, not reads or networking.
 * @param ctx - owning plugin context with all four required service injections.
 * @param root - directory interpreted only by the injected filesystem provider.
 * @param signal - optional cancellation for setup and the binding lifetime.
 * @returns ephemeral capabilities disposed with the caller's plugin generation.
 */
export declare function bindReadOnlyExecutionWorld(ctx: Context, root: string, signal?: AbortSignal): Promise<ReadOnlyExecutionWorld>;
//# sourceMappingURL=read-only.d.ts.map