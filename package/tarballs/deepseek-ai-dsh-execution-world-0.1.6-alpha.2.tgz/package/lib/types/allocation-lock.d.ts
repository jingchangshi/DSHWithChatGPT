/**
 * Serialize one fresh-open/read/write/close transaction without retaining contender handles.
 * All processes sharing identity storage must use the same absolute coordination path.
 * @param path - Host coordination path, never an execution-world workspace root.
 * @param waitMs - maximum contention wait; no live owner is forcibly displaced.
 * @param signal - cancellation before acquisition and before the operation starts.
 * @param operation - transaction that closes its storage handle before returning.
 * @returns the transaction result after releasing kernel ownership.
 */
export declare function withAllocationLock<Result>(path: string, waitMs: number, signal: AbortSignal, operation: () => Promise<Result>): Promise<Result>;
//# sourceMappingURL=allocation-lock.d.ts.map