/** Root-relative read capabilities and confined process requests for one live provider generation. */
import type { FsInfo, FsVersion } from '@deepseek-ai/dsh-fs';
import type { ConfinedArgv } from '@deepseek-ai/dsh-sandbox';
import type { SubprocessHandle } from '@deepseek-ai/dsh-subprocess';
import type { ExecutionWorkspaceId } from './types.ts';
/** A directory child without a raw provider target or executable path. */
export interface ReadOnlyExecutionEntry {
    /** Root-relative logical path using forward slashes. */
    path: string;
    /** Single logical path segment. */
    name: string;
    /** Resolved entry kind. */
    type: 'file' | 'directory' | 'other';
    /** Provider version when available. */
    version?: FsVersion;
    /** Byte size when available. */
    size?: number;
}
/** Canonical-path-checked reads without atomic namespace isolation; empty paths select the root. */
export interface ReadOnlyExecutionFs {
    /**
     * Read metadata for a contained target.
     * @param path - root-relative logical path without dot or backslash segments.
     * @param signal - optional caller cancellation.
     * @returns metadata, or undefined for an absent target.
     */
    stat(path: string, signal?: AbortSignal): Promise<FsInfo | undefined>;
    /**
     * Read a contained regular UTF-8 file.
     * @param path - root-relative logical file path.
     * @param signal - optional caller cancellation.
     * @returns decoded text under the provider's read limits.
     */
    readText(path: string, signal?: AbortSignal): Promise<string>;
    /**
     * Stream a contained regular UTF-8 file.
     * @param path - root-relative logical file path.
     * @param signal - optional caller cancellation.
     * @returns a single-use stream closed when the binding is disposed.
     */
    streamText(path: string, signal?: AbortSignal): Promise<AsyncIterable<string>>;
    /**
     * Read a bounded contained file.
     * @param path - root-relative logical file path.
     * @param maxBytes - caller-owned byte ceiling.
     * @param signal - optional caller cancellation.
     * @returns file bytes, rejecting files larger than the ceiling.
     */
    readBytes(path: string, maxBytes: number, signal?: AbortSignal): Promise<Uint8Array>;
    /**
     * Read a bounded byte window.
     * @param path - root-relative logical file path.
     * @param range - byte offset and requested length.
     * @param signal - optional caller cancellation.
     * @returns the available bytes in that window.
     */
    readByteRange(path: string, range: {
        offset: number;
        length: number;
    }, signal?: AbortSignal): Promise<Uint8Array>;
    /**
     * List contained children without exposing provider target keys.
     * @param path - root-relative logical directory path.
     * @param signal - optional caller cancellation.
     * @returns children with logical paths; escaped resolved children reject the listing.
     */
    listDir(path: string, signal?: AbortSignal): Promise<ReadOnlyExecutionEntry[]>;
}
/** Explicit command limits; confinement governs file effects, not visibility or networking. */
export interface ReadOnlyExecutionStart {
    /** Executable and arguments, never a shell command string. */
    argv: readonly [string, ...string[]];
    /** Root-relative working directory; omission selects the bound root. */
    cwd?: string;
    /** Explicit environment overlay on the provider's scrubbed base. */
    env?: Readonly<Record<string, string>>;
    /** Ignore input or supply text with a caller-selected UTF-8 byte ceiling. */
    stdin: 'ignore' | {
        data: string;
        maxBytes: number;
    };
    /** Independent raw stream or bounded in-memory tail, without spill files. */
    stdout: 'pipe' | {
        maxBytes: number;
    };
    /** Independent raw stream or bounded in-memory tail, without spill files. */
    stderr: 'pipe' | {
        maxBytes: number;
    };
    /** Positive termination grace in milliseconds, bounded by the subprocess provider. */
    graceMs: number;
    /** Cancellation during setup and the published process lifetime. */
    signal?: AbortSignal;
}
/** Original process handle plus unchanged confinement facts. */
export interface ReadOnlyExecutionProcess {
    /** Provider-owned streams, output readers, outcome, and process-range lifecycle. */
    handle: SubprocessHandle;
    /** Full or partial enforcement, never upgraded by the binding. */
    enforcement: ConfinedArgv['enforcement'];
    /** Provider-specific denial evidence. */
    denialSignatures: ConfinedArgv['denialSignatures'];
    /** Provider-specific runner failure evidence. */
    runnerFailureRules: ConfinedArgv['runnerFailureRules'];
}
/** Ephemeral capabilities over one root; workspace identity survives capability replacement. */
export interface ReadOnlyExecutionWorld {
    /** Durable root identity, not an access token. */
    workspaceId: ExecutionWorkspaceId;
    /** Internal filesystem reads with preparation-time canonical path checks, not security isolation. */
    fs: ReadOnlyExecutionFs;
    /** Confined subprocess operations with a root-contained working directory. */
    subprocess: {
        /**
         * Start one argv command after resolving its executable and read-only confinement.
         * @param spec - explicit input, output, environment and termination limits.
         * @returns the original managed handle and actual enforcement facts.
         */
        start(spec: ReadOnlyExecutionStart): Promise<ReadOnlyExecutionProcess>;
    };
    /**
     * Abort work and wait for outstanding reads, streams and managed process ranges.
     * @returns when binding-owned work is quiescent.
     */
    dispose(): Promise<void>;
}
//# sourceMappingURL=read-only-types.d.ts.map