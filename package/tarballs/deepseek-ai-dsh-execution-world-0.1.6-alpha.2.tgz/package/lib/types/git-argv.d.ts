/** Validate one complete consumer Git argv, excluding the executable name.
 * @param argv - fixed Git arguments from the collaboration consumer.
 * @param emptyFile - provider-platform empty-file operand for no-index diff.
 */
export declare function validateGitArgv(argv: readonly string[], emptyFile: 'NUL' | '/dev/null'): void;
//# sourceMappingURL=git-argv.d.ts.map