/** Host-local durable records for execution worlds and their canonical roots. */
import { z } from 'zod';
import type { ExecutionWorkspaceId } from './types.ts';
/** Only UUIDs and one-way root lookup keys reach the persisted identity domain. */
export declare const executionWorldDomain: {
    name: string;
    version: number;
    global: {
        schema: z.ZodObject<{
            localWorldId: z.ZodNullable<z.ZodUUID>;
        }, z.core.$strict>;
        initial: {
            localWorldId: null;
        };
    };
    tables: {
        roots: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            workspaceId: ExecutionWorkspaceId;
        }>;
    };
};
//# sourceMappingURL=spec.d.ts.map