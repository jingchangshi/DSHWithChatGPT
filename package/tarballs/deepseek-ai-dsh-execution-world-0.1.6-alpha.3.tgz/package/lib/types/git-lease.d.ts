/** Provider-backed fixed Git read lease for one execution-world root. */
import type { Context } from '@deepseek-ai/cordis';
import type { ExecutionWorkspaceId } from './types.ts';
/** The only execution surface exposed to the consumer Git data plane. */
export interface ExecutionGitExecutor {
    readonly workspaceId: ExecutionWorkspaceId;
    readonly emptyFile: 'NUL' | '/dev/null';
    readonly signal: AbortSignal;
    execute(args: readonly string[], options: {
        maxBytes: number;
        timeoutMs: number;
        signal: AbortSignal;
    }): Promise<{
        stdout: string;
        stderr: string;
        exitCode: number;
    }>;
}
/** A fixed Git executor plus its provider cleanup. */
export interface ExecutionGitLease {
    readonly workspaceId: ExecutionWorkspaceId;
    readonly assurance: 'full' | 'hardened-windows';
    readonly git: ExecutionGitExecutor;
    dispose(): Promise<void>;
}
/** Acquisition failed and provider cleanup could not be confirmed. */
export declare class ExecutionGitCleanupError extends Error {
    constructor(cause: AggregateError);
}
/** Bind fixed read-only Git execution to the same provider root used by file reads.
 * @param ctx - provider services for this execution world.
 * @param root - provider-resolved workspace root.
 * @param signal - cancellation of lease acquisition and execution.
 * @returns fixed Git executor with joined provider cleanup.
 */
export declare function bindExecutionGitLease(ctx: Context, root: string, signal?: AbortSignal, policy?: 'require-full' | 'allow-hardened-windows'): Promise<ExecutionGitLease>;
//# sourceMappingURL=git-lease.d.ts.map