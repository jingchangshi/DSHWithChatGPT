/**
 * Publish Browser Harness' own usage skill through the DSH skill registry.
 *
 * `browser-harness skill` prints a complete `SKILL.md` — YAML frontmatter plus
 * body — that teaches the model when a browser is warranted and how to drive the
 * harness. This module registers ONE skill with the existing DSH skill registry,
 * so it reaches the model through the same catalog, ranking, and loader as every
 * filesystem or bundled skill. No second skill loader exists.
 *
 * The registry is passed in rather than read from `ctx` because `skills` is
 * optional for this provider: declaring it in `inject` would refuse activation
 * whenever a composition omits the skill service, while a bare `ctx.skills`
 * access is rejected for an undeclared service.
 *
 * The body is the upstream text verbatim. DSH parses the frontmatter and takes
 * the name, description, and optional metadata from it; rewriting the body would
 * fork upstream documentation.
 *
 * @module
 */
import { type SkillRegistry } from '@deepseek-ai/dsh-skill';
/** Frontmatter the upstream skill must declare to be publishable. */
interface ParsedFrontmatter {
    name: string;
    description: string;
    whenToUse?: string;
}
/**
 * Split an upstream `SKILL.md` into its frontmatter fields and body.
 *
 * @param text - complete upstream skill document.
 * @returns the parsed fields and the remaining body, or undefined when the document is not a usable skill.
 */
export declare function parseSkillDocument(text: string): {
    frontmatter: ParsedFrontmatter;
    body: string;
} | undefined;
/**
 * Register the Browser Harness usage skill on the existing skill registry.
 *
 * The document is read once per catalog discovery and cached by the registry,
 * so the upstream executable runs at most once per catalog generation.
 *
 * @param ctx - context carrying the `skills` registry.
 * @param options - the installed command and any environment overrides.
 * @returns a disposer releasing the registration.
 */
export declare function registerBrowserHarnessSkill(skills: SkillRegistry, options: {
    command: string;
    args?: readonly string[];
    env: Record<string, string>;
}): () => void;
export {};
//# sourceMappingURL=skill.d.ts.map