/**
 * Project a Browser Harness screenshot path into durable model-visible content.
 *
 * `browser_screenshot` returns `{"path", "width", "height", "size_bytes"}` as
 * text, because the upstream server writes a PNG to disk instead of returning
 * MCP `ImageContent`. DSH's MCP bridge only stores an image when the result
 * already contains an `image` block, so without this projection the model
 * receives a local path and never the picture.
 *
 * The provider owns that convention, so it supplies the projection through the
 * shared MCP client's `projectResult` seam rather than teaching the bridge about
 * one upstream server.
 *
 * @module
 */
import type { Context } from '@deepseek-ai/cordis';
import type { McpResultProjectionContext, McpResultProjector } from '@deepseek-ai/dsh-mcp-client';
/**
 * Read the PNG path and image dimensions out of one raw screenshot result.
 *
 * The upstream text is JSON, and its exact shape is the upstream contract; a
 * missing or malformed field degrades to a diagnostic instead of failing the
 * completed browser action.
 *
 * @param context - the raw result and its upstream tool name.
 * @returns the absolute path plus declared dimensions, or undefined when this result is not a screenshot payload.
 */
export declare function screenshotPayload(context: McpResultProjectionContext): {
    path: string;
    width?: number;
    height?: number;
} | undefined;
/**
 * Build the projection that turns a screenshot path into a durable image block.
 *
 * Every failure path returns text instead of throwing: the screenshot itself
 * succeeded, so the model should still learn where the file is.
 *
 * @param ctx - provider context carrying optional attachment and LLM services.
 * @returns a projector for the shared MCP client's `projectResult` seam.
 */
export declare function createScreenshotProjection(ctx: Context): McpResultProjector;
//# sourceMappingURL=screenshot.d.ts.map