/** Browser Harness tools over its stdio MCP server, attached to the user's running Chrome. @module */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
/** Cordis identity for the Browser Harness MCP browser provider. */
export declare const name = "experimental-browser-use-browser-harness-mcp";
/** Services required for scoped MCP startup and prompt readiness checks. */
export declare const inject: string[];
/** Browser Harness installation, daemon, and browser endpoint settings. */
export interface Config {
    /** MCP server executable, spawned directly without a shell. */
    command: string;
    /** Arguments passed to that executable verbatim. */
    args: string[];
    /** Per-call timeout override in milliseconds; omission uses the MCP client default. */
    toolCallTimeoutMs?: number;
    /** Browser Harness home directory; omission uses its own default. */
    home?: string;
    /** Daemon name selecting one local daemon and its browser; omission uses `default`. */
    daemonName?: string;
    /** Refuse to start a daemon, requiring an already running one. */
    requireExistingDaemon?: boolean;
    /** Persist browser actions to local recordings; omission preserves the stored preference. */
    record?: boolean;
    /** Mark the controlled tab in the browser UI; omission preserves the daemon default. */
    tabMarker?: boolean;
    /** HTTP(S) debugging URL of the browser to drive; conflicts with `cdpWs`. */
    cdpUrl?: string;
    /** WS(S) browser debugging endpoint to drive; conflicts with `cdpUrl`. */
    cdpWs?: string;
}
/** Validate provider settings before the provider reserves browser use. */
export declare const Config: Schema<Partial<Config>, Config>;
/**
 * Reject a setting the provider cannot express safely.
 *
 * Both endpoints name one browser, so configuring two would silently ignore
 * one of them. An absent option must stay absent: Browser Harness reads its own
 * stored recording and tab-marker preferences, and an empty string would
 * override them rather than leave them alone.
 *
 * @param config - schema-validated provider settings.
 */
export declare function validateConfig(config: Config): void;
/**
 * Build the upstream environment overrides for the configured settings.
 *
 * Only configured options contribute; every variable this returns is one
 * Browser Harness actually reads, so a default here can never silently replace
 * a user's stored preference.
 *
 * @param config - schema-validated provider settings.
 * @returns environment overrides, empty when nothing is configured.
 */
export declare function buildEnvironment(config: Config): Record<string, string>;
/**
 * Expose Browser Harness' upstream catalog to one live Session at a time.
 *
 * One Browser Harness daemon drives one shared browser through mutable
 * current-tab state, so concurrent Sessions would interleave `switch_tab` and
 * act on each other's tab; `exclusive: true` reserves that single lane. The
 * browser stays externally owned: disposing this provider closes only the DSH
 * MCP client, leaving the daemon and the user's Chrome running.
 *
 * @param ctx - provider context supplying browser use, Agents, tools, and prompt assembly.
 * @param config - validated installation, daemon, and endpoint settings.
 */
export declare function apply(ctx: Context, config: Config): void;
/**
 * Locate the executable that prints the Browser Harness usage skill.
 *
 * `browser-harness-mcp` ships beside `browser-harness`, and the task configures
 * only the MCP executable, so the skill command is derived from it instead of
 * widening the config surface with a second path the user must keep in sync.
 *
 * @param command - configured MCP server executable.
 * @returns the sibling CLI path, or the configured command when it is not the MCP server.
 */
export declare function resolveSkillCommand(command: string): string;
/** Upstream variables this provider owns, exported for documentation checks. */
export declare const environmentKeys: readonly string[];
//# sourceMappingURL=index.d.ts.map